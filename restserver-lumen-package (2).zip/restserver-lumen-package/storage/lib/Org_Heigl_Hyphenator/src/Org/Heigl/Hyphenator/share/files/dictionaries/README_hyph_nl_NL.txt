                                [ENGLISH]
        You are kindly requested to read this file "license_en_EN.txt" 
     and to keep a copy of it with every copy you make of this language file.

1. Name: Dutch word list for spell checking - OpenTaal
2. Version of words list: 2.00G; version of spell checking: 2.00G.
3. Requirements: Hunspell 1.2.8 and higher
4. Spelling Seal of Dutch Language Union: The OpenTaal list of lemmas has 
   received the Spelling Seal of Approval from the Dutch Language Union, the 
   formal Dutch language institute. For more information please see: 
   http://www.taalunieversum.org/keurmerk/
5. Copyrights: © 2006-2010 OpenTaal, © 2001-2005 Simon Brouwer e.a., 
   © 1996 Nederlandstalige Tex Gebruikersgroep
6. Licenses: OpenTaal aims to create and publish free Dutch language files. To 
   enable the broadest (re)use the language files are freely available under the 
   below, liberal licenses at the discretion of the user. We strongly recommend 
   to read the applicable license before usage.
   A. BSD (revised version):
   - Full license text: http://creativecommons.org/licenses/BSD/legalcode
   - Summary: http://creativecommons.org/licenses/BSD/deed.en
   B. Creative Commons, Attribution 3.0 (unported)
   - Full license text: http://creativecommons.org/licenses/by/3.0/legalcode
   - Summary: http://creativecommons.org/licenses/by/3.0/deed.en
7. Support OpenTaal: OpenTaal is a non-profit volunteer project. With your 
   (small) financial support OpenTaal will further expand its activities and 
   enhance its professionalism. Your donation is welcome at
   account number: 15.62.32.782, BIC: RABONL2U, IBAN: NL88RABO0156232782 of 
   Stichting OpenTaal / OpenTaal Foundation. In the Netherlands your donations 
   are tax deductible. OpenTaal Foundation has been designated by the Dutch Tax 
   Administration as an Institution for General Benefit (algemeen nut beogende 
   instelling or ANBI). Please see: http://belastingdienst.nl/anbi/
8. Participate: Everyone is welcome to participate. Please give feedback, 
   discuss on the mailing list or run Harvester. By contributing to the project 
   you agree that your contribution is available under free or/open source 
   licenses. In case you wish, your name will be mentioned on the website. Your 
   are invited to send us your written request.
9. Rights of third parties: OpenTaal respects the rights of third parties and 
   aims to keep its data freely available. Therefore you may no use protected 
   sources of third parties, i.e. dictionaries, without their permission when 
   you contribute to the project. It is permitted to use the materials of the 
   Dutch Language Union, i.e. their spelling instruction and word list. In case 
   you believe OpenTaal is violating your rights, we ask you to send us a 
   written notice as soon as possible.
10.Contact: OpenTaal Foundation, http://www.opentaal.org, bestuur@opentaal.org

