Hyphenation dictionary
----------------------

Language: it_IT (Italian, Italy)
Origin:   Based on the TeX hyphenation tables by Claudio Beccari
License:  LGPL
	  http://tug.ctan.org/cgi-bin/ctanPackageInformation.py?id=ithyph
Author:   conversion author is Giuseppe Bilotta <giuseppe.bilotta@gmail.com>

This dictionary should be usable under other Italian variants

===============================================================================

Dizionario sillabazione
----------------------

Language: it_IT (Italiano, Italia)
Origin:   Basato sulle tabelle di sillabazione di Claudio Beccari per il TeX
License:  LGPL
	  http://tug.ctan.org/cgi-bin/ctanPackageInformation.py?id=ithyph
Author:   conversione di Giuseppe Bilotta <giuseppe.bilotta@gmail.com>

Questo dizionario dovrebbe essere valido anche per altre varianti di italiano

===============================================================================

HYPH it IT hyph_it_IT

