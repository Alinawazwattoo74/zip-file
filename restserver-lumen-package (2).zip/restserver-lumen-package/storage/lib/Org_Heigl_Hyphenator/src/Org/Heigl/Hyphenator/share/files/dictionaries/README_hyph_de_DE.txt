COMMENT OF THE EXTENSION OWNER
========================================================================================


This extension is based on:

Spell checking:
===============
de-DE_frami
Version: 2011-05-05
Author:  Franz Michael Baumann <frami.baumann@web.de>
License: GNU GPL Version 2 or GPL Version 3 or OASIS 0.1

The "frami"-dictionary contains the complete word list of Bj�rn Jacke's "igerman98" 
(Version: 2011-03-21) and numerous supplements by Franz Michael Baumann according to
the reform of 2006-08-01.

Hyphenation:
============
Authors: Marco Huggenberger <marco@by-night.ch> / Daniel Naber <naber at danielnaber de>
Version: 2011-06-03
		 Author and license information in source file added,
		 bug fixed because of that under LibO 3.4.0
License: GNU LGPL

Thesaurus:
==========
OpenThesaurus - Deutscher Thesaurus - Synonyme und Assoziationen
Version: 2011-05-04 DE
License: GNU LGPL
http://www.openthesaurus.de

Please note:
Even though having built and published the dictionary extension, the extension owner has
no responsibility for maintaining related dictionaries. For contacting the author of 
dictionaries, please read his related README files. Updated extension is intended to be 
published, as soon related dictionaries will have been actualized.

For contacting the extension owner write to:
karl<dot>zeiler<at>t-online.de
