
OpenOffice.org Spelling and Hyphenation for Serbian (Cyrillic and Latin)

Created by the Serbian OpenOffice.org community. Learn more about Serbian OOo
native-language project at http://sr.openoffice.org

OpenOffice.org 3 extension with autoupdate feature can be downloaded
from: http://extensions.services.openoffice.org/project/dict-sr
The content is same as in dict-sr extension release 2010-09-20

The dictionary content is based on the Hunspell dictionary and the Hyphen
hyphenation patterns for the Serbian language. All content of the dictionary can
be used under the terms of GNU LGPL version 3.

Serbian spellcheck dictionary (files sr.dic, sr.aff, sh.dic, sh.aff) is released
under disjunctive tri-licence GNU LGPL version 2.1 or later / MPL version 1.1 or
later / GNU GPL version 2 or later giving you the choice of one of the three
sets of free software licensing terms. You can also use the dictionary under the
terms of the Creative Commons BY-SA 3.0 Unpored licence.

Serbian hyphenation patterns (files hyph_sr.dic and hyph_sh.dic) are derived
from the official TeX patterns for Serbocroatian language (Cyrillic and Latin)
created by Dejan Muhamedagić <dejan@hello-penguin.com> version 2.02 released on
22 June 2008. The format is adopted for usage with Hyphen hyphenation library
and is released again as hyphen-sr under the compatible GNU LGPL version 2.1 or
later.


You can track development at http://gitorious.org/dict-sr/ Please send your
suggestions and contributions to the dev@sr.openoffice.org public mailing list
(http://sr.openoffice.org/servlets/SummarizeList?listName=dev)


Submodule repositories
  Hunspell dictionary:        http://gitorious.org/dict-sr/hunspell-sr
  Hyphen patterns:            http://gitorious.org/dict-sr/hyphen-sr

