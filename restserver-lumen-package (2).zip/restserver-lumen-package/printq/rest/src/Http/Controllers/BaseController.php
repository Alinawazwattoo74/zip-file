<?php

namespace Printq\Rest\Http\Controllers;

use App\Http\Controllers\Controller;

class BaseController extends Controller
{}