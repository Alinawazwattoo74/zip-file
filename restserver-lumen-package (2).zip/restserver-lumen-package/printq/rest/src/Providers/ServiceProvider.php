<?php

namespace Printq\Rest\Providers;

class ServiceProvider extends RestServiceProvider
{}