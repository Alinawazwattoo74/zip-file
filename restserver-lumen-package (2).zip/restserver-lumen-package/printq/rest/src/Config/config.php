<?php

return [
    'watermark_master_password' => '4zLWUyAwdHfF2Q2y',
    'pdf_license_key' => env("PDF_LICENSE_KEY", "L900602-0190B3-144087-GQGR32-LB3VA2")
];